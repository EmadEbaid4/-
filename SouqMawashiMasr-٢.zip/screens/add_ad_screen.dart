import 'package:flutter/material.dart';

class AddAdScreen extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('إضافة إعلان جديد')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(decoration: InputDecoration(labelText: 'نوع الحيوان')),
              TextFormField(decoration: InputDecoration(labelText: 'الوزن بالكيلو')),
              TextFormField(decoration: InputDecoration(labelText: 'السعر للكيلو')),
              TextFormField(decoration: InputDecoration(labelText: 'المدينة')),
              TextFormField(decoration: InputDecoration(labelText: 'رقم التليفون')),
              TextFormField(decoration: InputDecoration(labelText: 'وصف إضافي')),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم حفظ الإعلان')));
                  }
                },
                child: Text('نشر الإعلان'),
              )
            ],
          ),
        ),
      ),
    );
  }
}