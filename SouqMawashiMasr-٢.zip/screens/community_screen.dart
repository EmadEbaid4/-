import 'package:flutter/material.dart';

class CommunityScreen extends StatelessWidget {
  final List<String> posts = [
    'ما أفضل منشط كبد جربتوه؟',
    'مين عنده عجول وزن فوق 500؟'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('مجتمع الثروة الحيوانية')),
      body: ListView.builder(
        itemCount: posts.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Icon(Icons.person),
            title: Text(posts[index]),
            trailing: Icon(Icons.comment),
          );
        },
      ),
    );
  }
}