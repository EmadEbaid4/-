import 'package:flutter/material.dart';
import '../models/ad_model.dart';

class AdsListScreen extends StatelessWidget {
  final List<Ad> ads = [
    Ad(
      id: '1',
      title: 'عجل بلدي ممتاز',
      imageUrl: '',
      weight: 450,
      pricePerKg: 100,
      city: 'المنوفية',
      rating: 4.5,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('إعلانات الماشية')),
      body: ListView.builder(
        itemCount: ads.length,
        itemBuilder: (context, index) {
          final ad = ads[index];
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              title: Text(ad.title),
              subtitle: Text('الوزن: ${ad.weight} كجم - السعر: ${ad.pricePerKg} ج/كجم'),
              trailing: Icon(Icons.arrow_forward),
            ),
          );
        },
      ),
    );
  }
}