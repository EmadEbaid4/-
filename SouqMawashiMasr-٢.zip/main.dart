import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(SouqMawashiMasr());
}

class SouqMawashiMasr extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'سوق مواشي مصر',
      theme: ThemeData(
        fontFamily: 'Cairo',
        primarySwatch: Colors.green,
      ),
      home: HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}