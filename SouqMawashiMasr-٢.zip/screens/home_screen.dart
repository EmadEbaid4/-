import 'package:flutter/material.dart';
import 'ads_list_screen.dart';
import 'add_ad_screen.dart';
import 'community_screen.dart';
import 'vet_feed_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('سوق مواشي مصر'),
        centerTitle: true,
      ),
      body: Center(
        child: ElevatedButton(
          child: Text('دخول السوق'),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(
              builder: (context) => AdsListScreen(),
            ));
          },
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.store), label: 'الإعلانات'),
          BottomNavigationBarItem(icon: Icon(Icons.post_add), label: 'إضافة'),
          BottomNavigationBarItem(icon: Icon(Icons.group), label: 'المجتمع'),
          BottomNavigationBarItem(icon: Icon(Icons.medical_services), label: 'أدوية وأعلاف'),
        ],
        onTap: (index) {
          Widget nextScreen;
          switch (index) {
            case 0: nextScreen = AdsListScreen(); break;
            case 1: nextScreen = AddAdScreen(); break;
            case 2: nextScreen = CommunityScreen(); break;
            case 3: nextScreen = VetFeedScreen(); break;
            default: nextScreen = AdsListScreen();
          }
          Navigator.push(context, MaterialPageRoute(builder: (context) => nextScreen));
        },
      ),
    );
  }
}