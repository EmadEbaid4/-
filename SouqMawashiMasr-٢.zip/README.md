# سوق مواشي مصر – SouqMawashiMasr

هذا المشروع هو نسخة تجريبية أوفلاين من تطبيق تجارة المواشي في مصر.

## 📱 مميزات التطبيق:
- عرض إعلانات بيع وشراء الماشية.
- إضافة إعلان جديد.
- مجتمع للتفاعل بين المربين.
- قسم خاص بالأعلاف والأدوية البيطرية.

---

## 🧰 المتطلبات:

- Flutter SDK
- Android Studio أو VS Code
- Android Device أو Emulator

---

## 🚀 خطوات تشغيل التطبيق:

1. فك ضغط المشروع وافتحه في VS Code أو Android Studio.
2. افتح التيرمنال وشغل:

```bash
flutter pub get
```

3. لتشغيل التطبيق:

```bash
flutter run
```

---

## 📦 بناء ملف APK:

```bash
flutter build apk --release
```

ستجد الـ APK في:

```
build/app/outputs/flutter-apk/app-release.apk
```

---

## ✨ ملاحظات:

- الخط المستخدم هو الخط الافتراضي (يمكنك إضافة خط Cairo في `pubspec.yaml`).
- المشروع حاليًا لا يعتمد على أي قاعدة بيانات (نسخة أوفلاين).