import 'package:flutter/material.dart';

class VetFeedScreen extends StatelessWidget {
  final List<String> ads = [
    'فيتامين AD3E - منشط ممتاز بسعر خاص!',
    'علف تسمين عجول من شركة الريف الأخضر'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('إعلانات الأعلاف والأدوية')),
      body: ListView.builder(
        itemCount: ads.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              leading: Icon(Icons.medical_services),
              title: Text(ads[index]),
            ),
          );
        },
      ),
    );
  }
}