class Ad {
  final String id;
  final String title;
  final String imageUrl;
  final double weight;
  final double pricePerKg;
  final String city;
  final double rating;

  Ad({
    required this.id,
    required this.title,
    required this.imageUrl,
    required this.weight,
    required this.pricePerKg,
    required this.city,
    required this.rating,
  });
}